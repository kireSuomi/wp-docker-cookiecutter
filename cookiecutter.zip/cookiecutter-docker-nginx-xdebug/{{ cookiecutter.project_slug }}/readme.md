# Installation

1. `composer install`
2. `sudo chmod +x ./startdev.sh`
3. `./startdev.sh`

### Login for database

- **Database Name:** wordpress
- **Username:** root
- **Password:** admin
  <br>
- **Host:** localhost
- **Host mac:** host.docker.internal
