#!/bin/bash

# Install PHP dependencies using Composer
composer install

# Move wp-config.php into /webroot
mv wp-config.php ./webroot/

# Make the startdev.sh script executable
sudo chmod +x ./startdev.sh

# Run the startdev.sh script
./startdev.sh

# Open localhost:80 in the default web browser
xdg-open http://localhost:80